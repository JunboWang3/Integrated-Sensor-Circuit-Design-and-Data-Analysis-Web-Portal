from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import SensorViewSet, MeasurementViewSet
from .views import index

router = DefaultRouter()
router.register(r'Sensor', SensorViewSet)
router.register(r'Measurement', MeasurementViewSet)

urlpatterns = [
    path('api/', include(router.urls)),
    path('', index, name='index'),
]

from rest_framework import viewsets
from rest_framework.decorators import action
from rest_framework.response import Response
from .models import Sensor, Measurement
from .serializers import SensorSerializer, MeasurementSerializer
from django.shortcuts import render

class SensorViewSet(viewsets.ModelViewSet):
    queryset = Sensor.objects.all()
    serializer_class = SensorSerializer

    @action(detail=False, methods=['get'])
    def search(self, request):
        query = request.query_params.get('query', None)
        if query:
            sensors = self.queryset.filter(Sensor_ID__icontains=query)
            if sensors.exists():
                serializer = self.get_serializer(sensors, many=True)
                return Response(serializer.data)
            else:
                return Response({"detail": "No Sensor matches the given query."}, status=404)
        else:
            return Response({"detail": "Query parameter is missing."}, status=400)

class MeasurementViewSet(viewsets.ModelViewSet):
    queryset = Measurement.objects.all()
    serializer_class = MeasurementSerializer

    @action(detail=False, methods=['get'])
    def search(self, request):
        query = request.query_params.get('query', None)
        if query:
            measurements = self.queryset.filter(TimeZone__icontains=query)  # 使用 Location 字段进行搜索
            if measurements.exists():
                serializer = self.get_serializer(measurements, many=True)
                return Response(serializer.data)
            else:
                return Response({"detail": "No Measurement matches the given query."}, status=404)
        else:
            return Response({"detail": "Query parameter is missing."}, status=400)

def index(request):
    return render(request, 'frontend/public/index.html')

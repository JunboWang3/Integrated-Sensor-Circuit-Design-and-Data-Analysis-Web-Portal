from rest_framework import serializers
from .models import Sensor, Measurement

class SensorSerializer(serializers.ModelSerializer):
    class Meta:
        model = Sensor
        fields = ['Sensor_ID', 'Location', 'Sensor_Key']

class MeasurementSerializer(serializers.ModelSerializer):
    class Meta:
        model = Measurement
        fields = ['ID', 'Temperature', 'Humidity', 'Timestamp', 'TimeZone', 'Temperature_Change_Rate', 'Humidity_Change_Rate', 'Comfort_Index', 'Location', 'Sensor_ID', 'Comfort_Level']

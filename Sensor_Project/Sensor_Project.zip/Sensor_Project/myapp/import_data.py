import os
import sys
import pandas as pd
from django.core.wsgi import get_wsgi_application

#设置项目根目录
sys.path.append('C:/Users/Frank/Sensor_Project')
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'Sensor_Project.settings')
application = get_wsgi_application()

import django
django.setup()

from myapp.models import Sensors, Measurements

#定义Excel文件路径
excel_file_path = 'C:/Users/Frank/Desktop/New_DHT11_Data_Collection.xlsx'

#导入Sensors数据
def import_sensors():
    try:
        print("开始导入Sensors数据")
        df = pd.read_excel(excel_file_path, sheet_name='Sensors')  #使用实际的工作表名称
        print("Sensors数据加载成功")
        for _, row in df.iterrows():
            sensor = Sensors(
                Sensor_ID=row['Sensor ID'],
                Location=row['Location'],
                Sensor_Key=row['Sensor Key']
            )
            sensor.save()
        print("Sensors数据导入完成")
    except Exception as e:
        print(f"导入Sensors数据时出错: {e}")

#导入Measurements数据
def import_measurements():
    try:
        print("开始导入Measurements数据")
        df = pd.read_excel(excel_file_path, sheet_name='Measurements')  #使用实际的工作表名称
        print("Measurements数据加载成功")
        for _, row in df.iterrows():
            measurement = Measurements(
                Temperature=row['Temperature'],
                Humidity=row['Humidity'],
                Timestamp=row['Timestamp'],
                TimeZone=row['TimeZone'],
                Temperature_Change_Rate=row['Temperature Change Rate'],
                Humidity_Change_Rate=row['Humidity Change Rate'],
                Comfort_Index=row['Comfort Index'],
                Location=row['Location'],
                Sensor_ID=row['Sensor ID'],
                Comfort_Level=row['Comfort Level']
            )
            measurement.save()
        print("Measurements数据导入完成")
    except Exception as e:
        print(f"导入Measurements数据时出错: {e}")

#调用导入函数
import_sensors()
import_measurements()
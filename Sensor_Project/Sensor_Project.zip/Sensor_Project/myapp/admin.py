from django.contrib import admin
from .models import Sensor

# Register your models here.
admin.site.register(Sensor)
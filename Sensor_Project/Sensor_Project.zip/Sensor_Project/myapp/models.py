from django.db import models

# Create your models here.
class Sensor(models.Model): #定义Sensors模型
    Sensor_ID = models.CharField(max_length=100, primary_key=True)
    Location = models.CharField(max_length=100)
    Sensor_Key = models.PositiveIntegerField()
    
    class Meta:  #设置模型的元数据
        db_table = 'Sensors' #指定数据库表名为'sensors'
    
class Measurement(models.Model): #定义测量数据模型
    ID = models.PositiveIntegerField()
    Temperature = models.FloatField()
    Humidity = models.FloatField()
    Timestamp = models.DateTimeField()
    TimeZone = models.CharField(max_length=100, default='unknown')
    Temperature_Change_Rate = models.CharField(max_length=50, null=True, blank=True)
    Humidity_Change_Rate = models.CharField(max_length=50, null=True, blank=True)
    Comfort_Index = models.FloatField()
    Location = models.CharField(max_length=100)
    Sensor_ID = models.PositiveIntegerField()
    Comfort_Level = models.CharField(max_length=100, default='unknown')                     
    
    class Meta: #设置模型的元数据
        db_table = 'Measurements' #指定数据库表名为'measurements'
